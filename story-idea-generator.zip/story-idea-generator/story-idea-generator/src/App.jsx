import React, { useState } from "react";

export default function StoryIdeaGenerator() {
  const GENRES = [
    "Fantasy",
    "Science Fiction",
    "Mystery",
    "Horror",
    "Romance",
    "Historical",
    "Thriller",
    "Slice of Life",
    "Magical Realism",
    "Adventure",
  ];

  const THEMES = [
    "Redemption",
    "Coming of Age",
    "Betrayal",
    "Friendship",
    "Identity",
    "Survival",
    "Power and Corruption",
    "Love vs Duty",
    "Sacrifice",
    "Secrets",
  ];

  const ARCHETYPES = [
    "Reluctant Hero",
    "Trickster",
    "Mentor",
    "Anti-hero",
    "Detective",
    "Outcast",
    "Innocent",
    "Rival",
    "Healer",
    "Rebel",
  ];

  const SETTINGS = [
    "a bustling port city",
    "an isolated mountain village",
    "a sprawling corporate arcology",
    "an ancient library",
    "a dying colony ship",
    "a small-town diner",
    "a secretive monastery",
    "a neon-drenched megacity",
    "a frontier outpost",
    "a sunken underwater city",
  ];

  const CONFLICTS = [
    "a broken treaty",
    "a missing person",
    "a forbidden technology",
    "an ancient prophecy",
    "a cursed heirloom",
    "a public scandal",
    "a tightened quarantine",
    "a mysterious signal",
    "a contested inheritance",
    "a sudden law banning emotions",
  ];

  const [selectedGenres, setSelectedGenres] = useState(["Fantasy"]);
  const [selectedTheme, setSelectedTheme] = useState("Redemption");
  const [selectedArchetype, setSelectedArchetype] = useState("Reluctant Hero");
  const [extraConstraints, setExtraConstraints] = useState("");
  const [numVariants, setNumVariants] = useState(3);
  const [ideas, setIdeas] = useState([]);

  const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

  const TEMPLATES = [
    ({ g, t, a, s, c, x }) =>
      `In a ${s} (${g}), ${a} faces ${t.toLowerCase()}. The story begins when ${c}. ${x}`,
    ({ g, t, a, s, c, x }) =>
      `Write a ${g} story about ${a} struggling with ${t.toLowerCase()} in ${s}. Everything changes when ${c}. ${x}`,
    ({ g, t, a, s, c, x }) =>
      `A ${g} tale: ${a} must choose between ${t.toLowerCase()} and personal desire. The world is ${s}. ${c} sparks the conflict. ${x}`,
    ({ g, t, a, s, c, x }) =>
      `Prompt: ${g} | Theme: ${t} | Character: ${a} | Setting: ${s}. Start when ${c}. ${x}`,
  ];

  function generateOne() {
    // ✅ Use all selected genres instead of one
    const g = selectedGenres.join(" + ");
    const t = selectedTheme || pick(THEMES);
    const a = selectedArchetype || pick(ARCHETYPES);
    const s = pick(SETTINGS);
    const c = pick(CONFLICTS);
    const flavors = [
      "Add a moral dilemma that forces the protagonist to choose.",
      "Reveal a secret that changes everything.",
      "Include a vivid sensory description of a key object.",
      "Make the antagonist sympathetic by showing their pain.",
      "End on an ambiguous emotional note.",
    ];

    let x = pick(flavors);
    if (extraConstraints.trim()) x = extraConstraints.trim() + " — " + x;

    const tmpl = pick(TEMPLATES);
    const ideaText = tmpl({ g, t, a, s, c, x });
    return {
      id: Math.random().toString(36).slice(2, 9),
      genre: g,
      theme: t,
      archetype: a,
      setting: s,
      conflict: c,
      twist: x,
      text: ideaText,
      createdAt: new Date().toISOString(),
    };
  }

  function generateIdeas() {
    const n = Math.max(1, Math.min(12, Number(numVariants) || 3));
    const out = Array.from({ length: n }, () => generateOne());
    setIdeas(out);
  }

  function toggleGenre(g) {
    setSelectedGenres((prev) =>
      prev.includes(g) ? prev.filter((x) => x !== g) : [...prev, g]
    );
  }

  function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(
      () => alert("Copied to clipboard!"),
      () => alert("Failed to copy.")
    );
  }

  function downloadJSON() {
    const blob = new Blob([JSON.stringify(ideas, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `story-ideas-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-200 via-orange-100 to-sky-200 p-8 font-sans transition-all duration-500">
      <div className="max-w-5xl mx-auto bg-white/90 backdrop-blur-lg shadow-2xl rounded-3xl p-8 border border-pink-100">
        <h1 className="text-3xl font-extrabold text-center text-sky-700 mb-3 drop-shadow-md">
          🌈 Story Idea Generator
        </h1>
        <p className="text-center text-gray-700 mb-8">
          Combine genres, themes, and archetypes to spark creative story ideas!
        </p>

        {/* Genre Buttons */}
        <div>
          <h2 className="font-semibold mb-2 text-lg">🎭 Genres (toggle multiple)</h2>
          <div className="flex flex-wrap gap-2 mb-4">
            {GENRES.map((g) => (
              <button
                key={g}
                onClick={() => toggleGenre(g)}
                className={`px-4 py-2 rounded-full shadow-md transition-all duration-300 ${
                  selectedGenres.includes(g)
                    ? "bg-gradient-to-r from-sky-500 to-indigo-500 text-white scale-105"
                    : "bg-white hover:bg-sky-100 text-gray-700"
                }`}
              >
                {g}
              </button>
            ))}
          </div>
        </div>

        {/* Select Options */}
        <div className="grid md:grid-cols-3 gap-4 mb-6">
          <div>
            <label className="font-semibold">🎨 Theme</label>
            <select
              value={selectedTheme}
              onChange={(e) => setSelectedTheme(e.target.value)}
              className="w-full p-2 rounded border mt-1"
            >
              {THEMES.map((t) => (
                <option key={t}>{t}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="font-semibold">🧙 Character Archetype</label>
            <select
              value={selectedArchetype}
              onChange={(e) => setSelectedArchetype(e.target.value)}
              className="w-full p-2 rounded border mt-1"
            >
              {ARCHETYPES.map((a) => (
                <option key={a}>{a}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="font-semibold">🧩 Variants</label>
            <input
              type="number"
              value={numVariants}
              onChange={(e) => setNumVariants(e.target.value)}
              min={1}
              max={12}
              className="w-full p-2 rounded border mt-1"
            />
          </div>
        </div>

        {/* Extra Prompt */}
        <label className="font-semibold">💡 Extra Constraint (optional)</label>
        <input
          value={extraConstraints}
          onChange={(e) => setExtraConstraints(e.target.value)}
          placeholder="e.g. set in winter, written in first person"
          className="w-full p-3 rounded border mb-6 mt-1"
        />

        {/* Buttons */}
        <div className="flex justify-center gap-3 mb-6">
          <button
            onClick={generateIdeas}
            className="px-6 py-2 rounded-full bg-gradient-to-r from-pink-500 to-orange-400 text-white font-semibold hover:scale-105 transition-transform"
          >
            Generate Ideas ✨
          </button>
          <button
            onClick={() => {
              setIdeas([]);
              setExtraConstraints("");
              setSelectedGenres([]);
            }}
            className="px-6 py-2 rounded-full border border-gray-400 text-gray-700 hover:bg-gray-100 transition"
          >
            Reset
          </button>
        </div>

        {/* Generated Ideas */}
        <div>
          <h2 className="text-xl font-bold text-sky-700 mb-3">📝 Generated Ideas</h2>
          {ideas.length === 0 && (
            <p className="text-gray-600">No ideas yet — click Generate!</p>
          )}

          <div className="space-y-4">
            {ideas.map((item) => (
              <div
                key={item.id}
                className="p-4 bg-gradient-to-r from-white to-sky-50 rounded-xl shadow-md border hover:shadow-xl transition"
              >
                <div className="text-sm text-gray-500 mb-1">
                  {item.genre} • {item.theme} • {item.archetype}
                </div>
                <p className="font-medium text-gray-800">{item.text}</p>
                <div className="text-xs text-gray-400 mt-1">
                  {new Date(item.createdAt).toLocaleString()}
                </div>
                <div className="flex gap-2 mt-2">
                  <button
                    onClick={() => copyToClipboard(item.text)}
                    className="px-3 py-1 rounded-full text-sm border hover:bg-sky-100"
                  >
                    Copy
                  </button>
                  <button
                    onClick={() =>
                      setIdeas((prev) => prev.filter((x) => x.id !== item.id))
                    }
                    className="px-3 py-1 rounded-full text-sm border hover:bg-red-100"
                  >
                    Remove
                  </button>
                </div>
              </div>
            ))}
          </div>

          {ideas.length > 0 && (
            <div className="mt-4 flex gap-3">
              <button
                onClick={() =>
                  copyToClipboard(ideas.map((i) => i.text).join("\n\n"))
                }
                className="px-4 py-2 bg-sky-600 text-white rounded-full hover:scale-105 transition"
              >
                Copy All
              </button>
              <button
                onClick={downloadJSON}
                className="px-4 py-2 bg-white border rounded-full hover:bg-gray-100 transition"
              >
                Download JSON
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
